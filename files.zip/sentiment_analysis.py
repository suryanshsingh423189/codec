"""
Sentiment Analysis on Twitter Data
====================================
Classifies tweets as Positive, Negative, or Neutral using two approaches:
  1. Rule-based  — VADER (NLTK)
  2. ML-based    — TF-IDF + Logistic Regression (scikit-learn)

Both models are evaluated and their predictions compared.

Usage:
    python sentiment_analysis.py
"""

import re
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix, accuracy_score, ConfusionMatrixDisplay
)
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")


# ──────────────────────────────────────────────
# 1. SAMPLE TWEET DATASET
# ──────────────────────────────────────────────

TWEETS = [
    # POSITIVE
    ("I absolutely love the new iPhone! Best phone ever 😍", "positive"),
    ("Just got promoted!! So happy and grateful 🎉🎊", "positive"),
    ("The weather is beautiful today, perfect for a picnic 🌞", "positive"),
    ("Amazing performance by the team tonight! We won!! 🏆", "positive"),
    ("Feeling blessed and thankful for all the support I received 💙", "positive"),
    ("Just finished my first 5K run! Feeling unstoppable 💪", "positive"),
    ("Great coffee, great vibes, great morning ☕✨", "positive"),
    ("So excited for the upcoming road trip with friends!", "positive"),
    ("This movie is absolutely mind-blowing! 10/10 would recommend", "positive"),
    ("Cooked a delicious homemade pasta today, really proud of myself!", "positive"),
    ("My dog learned a new trick today 🐶❤️ Best day ever", "positive"),
    ("Fantastic customer service, will definitely come back!", "positive"),
    ("Just booked tickets to Paris! Dreams really do come true 🗼", "positive"),
    ("The new album is fire 🔥 Can't stop listening!", "positive"),
    ("Got engaged!! I said YES! Happiest day of my life 💍", "positive"),
    ("Shoutout to all the wonderful teachers out there, you matter!", "positive"),
    ("Passed my driving test first attempt! Absolutely thrilled!", "positive"),
    ("Best birthday surprise ever, so loved and appreciated 🎂", "positive"),
    ("Technology is amazing, just video called my family overseas!", "positive"),
    ("Sunrise hike was worth every step 🌅 Gorgeous views", "positive"),

    # NEGATIVE
    ("This is the worst service I have ever experienced. Absolutely terrible!", "negative"),
    ("Stuck in traffic for 2 hours. This city is a nightmare 😤", "negative"),
    ("My flight got cancelled again. Third time this month! So frustrated", "negative"),
    ("The restaurant food was cold and the staff were rude. Never going back", "negative"),
    ("Lost my wallet on the subway. Worst Monday ever 😭", "negative"),
    ("Terrible movie, waste of money and time. Do not watch!", "negative"),
    ("Data breach exposed my personal info. Furious at this company!", "negative"),
    ("Another sleepless night thanks to the noisy neighbours. Exhausted 😞", "negative"),
    ("Scammed by an online store. Stay away from them! 🚨", "negative"),
    ("Can't believe they cancelled my favourite show. Heartbroken 💔", "negative"),
    ("Awful weather ruined our outdoor event. So disappointed", "negative"),
    ("My laptop crashed and I lost all my work. Absolutely devastated", "negative"),
    ("Package arrived damaged and customer support was zero help", "negative"),
    ("Hospital wait times are ridiculous. This is unacceptable", "negative"),
    ("Just got a parking ticket despite paying. So unfair and annoying!", "negative"),
    ("Gym was filthy and equipment broken. Won't be renewing my membership", "negative"),
    ("App crashes every time I open it. Terrible development team 😡", "negative"),
    ("Queue was an hour long for a 2-minute ride. Not worth it at all", "negative"),
    ("Disappointed with the quality, expected so much better", "negative"),
    ("Failed my exam despite studying hard. Feel like giving up 😢", "negative"),

    # NEUTRAL
    ("The meeting has been rescheduled to Thursday at 3 PM.", "neutral"),
    ("It rained most of the day in London today.", "neutral"),
    ("The store opens at 9 AM and closes at 6 PM on weekdays.", "neutral"),
    ("New software update is available for download.", "neutral"),
    ("The report will be published next week.", "neutral"),
    ("Scientists discovered a new species of beetle in the Amazon.", "neutral"),
    ("The stock market closed slightly higher on Friday.", "neutral"),
    ("There are currently 42 items in your shopping cart.", "neutral"),
    ("The temperature tomorrow will be around 18 degrees Celsius.", "neutral"),
    ("The bus arrives every 15 minutes on weekdays.", "neutral"),
    ("The conference will be held virtually this year.", "neutral"),
    ("New regulations come into effect from January 1st.", "neutral"),
    ("The library is closed on public holidays.", "neutral"),
    ("Government announced a 2% increase in public sector pay.", "neutral"),
    ("The population of the city is approximately 3.5 million.", "neutral"),
    ("Construction on the new bridge is expected to finish by Q3.", "neutral"),
    ("The candidate submitted the application on Monday.", "neutral"),
    ("Survey results are currently being tabulated.", "neutral"),
    ("The satellite was launched successfully this morning.", "neutral"),
    ("The annual report will be released in PDF format.", "neutral"),
]


# ──────────────────────────────────────────────
# 2. TEXT PREPROCESSING
# ──────────────────────────────────────────────

_stop_words  = set(stopwords.words("english"))
_lemmatizer  = WordNetLemmatizer()

def preprocess(text: str) -> str:
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)          # URLs
    text = re.sub(r"@\w+", "", text)                     # mentions
    text = re.sub(r"#\w+", "", text)                     # hashtags
    text = re.sub(r"[^a-z\s]", " ", text)               # punctuation / emojis
    tokens = text.split()
    tokens = [_lemmatizer.lemmatize(t) for t in tokens if t not in _stop_words and len(t) > 1]
    return " ".join(tokens)


# ──────────────────────────────────────────────
# 3. VADER (RULE-BASED)
# ──────────────────────────────────────────────

_vader = SentimentIntensityAnalyzer()

def vader_label(text: str) -> str:
    score = _vader.polarity_scores(text)["compound"]
    if   score >=  0.05: return "positive"
    elif score <= -0.05: return "negative"
    else:                return "neutral"


# ──────────────────────────────────────────────
# 4. ML PIPELINE  (TF-IDF + Logistic Regression)
# ──────────────────────────────────────────────

def build_ml_pipeline() -> Pipeline:
    return Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=5_000, sublinear_tf=True)),
        ("clf",   LogisticRegression(max_iter=1_000, C=5, class_weight="balanced")),
    ])


# ──────────────────────────────────────────────
# 5. VISUALISATION
# ──────────────────────────────────────────────

COLORS = {"positive": "#3fb950", "negative": "#f78166", "neutral": "#58a6ff"}
LABEL_ORDER = ["negative", "neutral", "positive"]


def plot_all(df: pd.DataFrame, cm_ml, cm_vd, cv_scores, out="sentiment_analysis.png"):
    fig = plt.figure(figsize=(18, 11), facecolor="#0d1117")
    gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.38)

    ax_dist  = fig.add_subplot(gs[0, 0])
    ax_cvd   = fig.add_subplot(gs[0, 1])
    ax_cv    = fig.add_subplot(gs[0, 2])
    ax_cm1   = fig.add_subplot(gs[1, 0])
    ax_cm2   = fig.add_subplot(gs[1, 1])
    ax_agree = fig.add_subplot(gs[1, 2])

    for ax in fig.get_axes():
        ax.set_facecolor("#161b22")
        for spine in ax.spines.values():
            spine.set_color("#30363d")
        ax.tick_params(colors="#8b949e", labelsize=8)
        ax.title.set_color("#e6edf3")
        ax.xaxis.label.set_color("#8b949e")
        ax.yaxis.label.set_color("#8b949e")

    # 1) Label distribution
    counts = df["label"].value_counts()[LABEL_ORDER]
    ax_dist.bar(LABEL_ORDER, counts.values, color=[COLORS[l] for l in LABEL_ORDER], edgecolor="#0d1117")
    ax_dist.set_title("Dataset Label Distribution")
    ax_dist.set_ylabel("Count")
    for i, v in enumerate(counts.values):
        ax_dist.text(i, v + 0.3, str(v), ha="center", color="#e6edf3", fontsize=9)

    # 2) VADER confidence (compound score density)
    for lbl in LABEL_ORDER:
        subset = df[df["label"] == lbl]["vader_compound"]
        ax_cvd.hist(subset, bins=15, alpha=0.6, label=lbl, color=COLORS[lbl])
    ax_cvd.axvline( 0.05, color="white", linestyle="--", linewidth=0.8)
    ax_cvd.axvline(-0.05, color="white", linestyle="--", linewidth=0.8)
    ax_cvd.set_title("VADER Compound Score Distribution")
    ax_cvd.set_xlabel("Compound Score")
    ax_cvd.legend(facecolor="#161b22", edgecolor="#30363d", labelcolor="#e6edf3", fontsize=7)

    # 3) Cross-validation accuracy
    ax_cv.bar(range(len(cv_scores)), cv_scores, color="#58a6ff", edgecolor="#0d1117")
    ax_cv.axhline(cv_scores.mean(), color="#f78166", linestyle="--", linewidth=1.2, label=f"Mean={cv_scores.mean():.2%}")
    ax_cv.set_title("ML Model – 5-Fold CV Accuracy")
    ax_cv.set_xlabel("Fold")
    ax_cv.set_ylabel("Accuracy")
    ax_cv.set_xticks(range(len(cv_scores)))
    ax_cv.set_xticklabels([f"F{i+1}" for i in range(len(cv_scores))])
    ax_cv.set_ylim(0, 1.1)
    ax_cv.legend(facecolor="#161b22", edgecolor="#30363d", labelcolor="#e6edf3", fontsize=8)

    # 4 & 5) Confusion matrices
    for ax_cm, cm, title in [
        (ax_cm1, cm_ml, "ML Model Confusion Matrix"),
        (ax_cm2, cm_vd, "VADER Confusion Matrix"),
    ]:
        disp = ConfusionMatrixDisplay(cm, display_labels=LABEL_ORDER)
        disp.plot(ax=ax_cm, colorbar=False, cmap="Blues")
        ax_cm.set_title(title)
        ax_cm.set_facecolor("#161b22")
        ax_cm.images[0].set_clim(0, cm.max())

    # 6) Model agreement
    agree = (df["ml_pred"] == df["vader_pred"]).sum()
    disagree = len(df) - agree
    ax_agree.pie(
        [agree, disagree],
        labels=["Agree", "Disagree"],
        colors=["#3fb950", "#f78166"],
        autopct="%1.0f%%", startangle=90,
        textprops={"color": "#e6edf3", "fontsize": 9},
        wedgeprops={"edgecolor": "#0d1117"},
    )
    ax_agree.set_title("ML vs VADER Agreement")

    fig.suptitle("Twitter Sentiment Analysis Dashboard",
                 color="#e6edf3", fontsize=15, y=1.01)
    plt.savefig(out, dpi=150, bbox_inches="tight", facecolor="#0d1117")
    print(f"  Chart saved → {out}")


# ──────────────────────────────────────────────
# 6. MAIN
# ──────────────────────────────────────────────

def main():
    print(f"\n{'═'*50}")
    print(f"  Sentiment Analysis on Twitter Data")
    print(f"{'═'*50}")

    # Build DataFrame
    df = pd.DataFrame(TWEETS, columns=["text", "label"])
    df["clean"]          = df["text"].apply(preprocess)
    df["vader_compound"] = df["text"].apply(lambda t: _vader.polarity_scores(t)["compound"])
    df["vader_pred"]     = df["text"].apply(vader_label)
    print(f"\n  Total tweets : {len(df)}")
    print(f"  Labels       : {df['label'].value_counts().to_dict()}")

    # ── VADER evaluation ──────────────────────
    vader_acc = accuracy_score(df["label"], df["vader_pred"])
    print(f"\n{'─'*50}")
    print(f"  VADER (Rule-Based) Accuracy: {vader_acc:.2%}")
    print(f"{'─'*50}")
    print(classification_report(df["label"], df["vader_pred"],
                                 target_names=LABEL_ORDER, zero_division=0))

    cm_vd = confusion_matrix(df["label"], df["vader_pred"], labels=LABEL_ORDER)

    # ── ML model ─────────────────────────────
    X = df["clean"]
    y = df["label"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    pipe = build_ml_pipeline()
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)

    ml_acc = accuracy_score(y_test, y_pred)
    print(f"\n{'─'*50}")
    print(f"  ML Model (TF-IDF + Logistic Regression) Accuracy: {ml_acc:.2%}")
    print(f"{'─'*50}")
    print(classification_report(y_test, y_pred, target_names=LABEL_ORDER, zero_division=0))

    cm_ml = confusion_matrix(y_test, y_pred, labels=LABEL_ORDER)

    # Cross-validation on full dataset
    cv_scores = cross_val_score(
        build_ml_pipeline(), X, y,
        cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=0),
        scoring="accuracy"
    )
    print(f"  5-Fold CV Accuracy : {cv_scores.mean():.2%} ± {cv_scores.std():.2%}")

    # Add ML predictions to full dataframe for agreement chart
    df["ml_pred"] = pipe.predict(X)

    # ── Live demo ─────────────────────────────
    demo_tweets = [
        "Just got the best news of my life!! Can't stop smiling 😊",
        "This product is absolute garbage, I want my money back",
        "The session will begin at 10 AM tomorrow in Room 4B.",
    ]
    print(f"\n{'─'*50}")
    print("  Live Prediction Demo")
    print(f"{'─'*50}")
    for tw in demo_tweets:
        ml_label = pipe.predict([preprocess(tw)])[0]
        vd_label = vader_label(tw)
        print(f"  Tweet    : {tw[:60]}")
        print(f"  ML pred  : {ml_label}  |  VADER pred : {vd_label}")
        print()

    # ── Plot ──────────────────────────────────
    plot_all(df, cm_ml, cm_vd, cv_scores)

    print("  Done!\n")


if __name__ == "__main__":
    main()
