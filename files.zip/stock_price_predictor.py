"""
Stock Price Predictor
=====================
Predicts future stock closing prices using historical data.
Techniques: Linear Regression + feature engineering (moving averages, RSI, lag features).

Usage:
    python stock_price_predictor.py              # uses built-in sample data
    python stock_price_predictor.py --ticker AAPL  # live data via yfinance (needs internet)
"""

import argparse
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")


# ──────────────────────────────────────────────
# 1. DATA
# ──────────────────────────────────────────────

def generate_sample_data(n: int = 500, seed: int = 42) -> pd.DataFrame:
    """Synthetic OHLCV data that mimics a real stock."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2022-01-03", periods=n)
    close = [150.0]
    for _ in range(n - 1):
        close.append(close[-1] * np.exp(rng.normal(0.0003, 0.015)))
    close = np.array(close)
    df = pd.DataFrame({
        "Date": dates,
        "Open":   close * (1 + rng.uniform(-0.005, 0.005, n)),
        "High":   close * (1 + rng.uniform(0.000, 0.010, n)),
        "Low":    close * (1 - rng.uniform(0.000, 0.010, n)),
        "Close":  close,
        "Volume": rng.integers(5_000_000, 30_000_000, n),
    })
    df.set_index("Date", inplace=True)
    return df


def fetch_live_data(ticker: str) -> pd.DataFrame:
    try:
        import yfinance as yf
        df = yf.download(ticker, period="2y", auto_adjust=True, progress=False)
        if df.empty:
            raise ValueError(f"No data for ticker '{ticker}'.")
        return df[["Open", "High", "Low", "Close", "Volume"]]
    except Exception as e:
        print(f"[WARNING] Could not fetch live data ({e}). Falling back to sample data.")
        return generate_sample_data()


# ──────────────────────────────────────────────
# 2. FEATURE ENGINEERING
# ──────────────────────────────────────────────

def rsi(series: pd.Series, window: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(window).mean()
    loss = (-delta.clip(upper=0)).rolling(window).mean()
    rs = gain / (loss + 1e-9)
    return 100 - 100 / (1 + rs)


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Moving averages
    for w in [5, 10, 20, 50]:
        df[f"MA{w}"] = df["Close"].rolling(w).mean()

    # Exponential moving averages
    for w in [12, 26]:
        df[f"EMA{w}"] = df["Close"].ewm(span=w, adjust=False).mean()

    # MACD
    df["MACD"] = df["EMA12"] - df["EMA26"]

    # RSI
    df["RSI14"] = rsi(df["Close"])

    # Bollinger band width
    df["BB_mid"]   = df["Close"].rolling(20).mean()
    df["BB_std"]   = df["Close"].rolling(20).std()
    df["BB_width"] = df["BB_std"] / (df["BB_mid"] + 1e-9)

    # Daily return & volatility
    df["Return1"]  = df["Close"].pct_change()
    df["Volatility10"] = df["Return1"].rolling(10).std()

    # Volume z-score
    df["Vol_zscore"] = (
        (df["Volume"] - df["Volume"].rolling(20).mean())
        / (df["Volume"].rolling(20).std() + 1e-9)
    )

    # Lag features (previous closes)
    for lag in [1, 2, 3, 5]:
        df[f"Lag{lag}"] = df["Close"].shift(lag)

    # Target: next-day close
    df["Target"] = df["Close"].shift(-1)

    return df.dropna()


# ──────────────────────────────────────────────
# 3. MODEL
# ──────────────────────────────────────────────

def build_pipeline() -> Pipeline:
    return Pipeline([
        ("scaler", StandardScaler()),
        ("model",  Ridge(alpha=1.0)),
    ])


def train_test_split_ts(df: pd.DataFrame, test_ratio: float = 0.2):
    """Time-series split (no shuffling)."""
    split = int(len(df) * (1 - test_ratio))
    feature_cols = [c for c in df.columns if c not in ("Target",)]
    X = df[feature_cols].values
    y = df["Target"].values
    return X[:split], X[split:], y[:split], y[split:], df.index[split:]


# ──────────────────────────────────────────────
# 4. EVALUATION
# ──────────────────────────────────────────────

def evaluate(y_true, y_pred, label="Test"):
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred) ** 0.5
    r2   = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-9))) * 100
    print(f"\n{'─'*40}")
    print(f"  {label} Metrics")
    print(f"{'─'*40}")
    print(f"  MAE  : ${mae:>8.4f}")
    print(f"  RMSE : ${rmse:>8.4f}")
    print(f"  MAPE : {mape:>8.2f}%")
    print(f"  R²   : {r2:>8.4f}")
    print(f"{'─'*40}")
    return {"MAE": mae, "RMSE": rmse, "MAPE": mape, "R2": r2}


# ──────────────────────────────────────────────
# 5. VISUALISATION
# ──────────────────────────────────────────────

def plot_results(dates, y_true, y_pred, ticker, out_path="stock_prediction.png"):
    fig, axes = plt.subplots(2, 1, figsize=(14, 9), facecolor="#0d1117")
    for ax in axes:
        ax.set_facecolor("#161b22")
        for spine in ax.spines.values():
            spine.set_color("#30363d")
        ax.tick_params(colors="#8b949e")

    # --- Top: price plot ---
    ax = axes[0]
    ax.plot(dates, y_true, label="Actual",    color="#58a6ff", linewidth=1.4)
    ax.plot(dates, y_pred, label="Predicted", color="#f78166", linewidth=1.2, linestyle="--")
    ax.set_title(f"{ticker} — Next-Day Close Price Prediction",
                 color="#e6edf3", fontsize=13, pad=10)
    ax.set_ylabel("Price (USD)", color="#8b949e")
    ax.legend(facecolor="#161b22", edgecolor="#30363d", labelcolor="#e6edf3")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    fig.autofmt_xdate()

    # --- Bottom: residuals ---
    ax2 = axes[1]
    residuals = y_true - y_pred
    ax2.bar(dates, residuals, color=np.where(residuals >= 0, "#3fb950", "#f78166"),
            width=1, alpha=0.8)
    ax2.axhline(0, color="#8b949e", linewidth=0.8)
    ax2.set_title("Prediction Residuals (Actual − Predicted)", color="#e6edf3", fontsize=11, pad=8)
    ax2.set_ylabel("Residual (USD)", color="#8b949e")
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax2.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    fig.autofmt_xdate()

    plt.tight_layout(pad=2.5)
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"\n  Chart saved → {out_path}")


# ──────────────────────────────────────────────
# 6. MAIN
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Stock Price Predictor")
    parser.add_argument("--ticker", default=None, help="Yahoo Finance ticker, e.g. AAPL")
    args = parser.parse_args()

    ticker = args.ticker.upper() if args.ticker else "SAMPLE"
    print(f"\n{'═'*45}")
    print(f"  Stock Price Predictor  |  {ticker}")
    print(f"{'═'*45}")

    # Load data
    if args.ticker:
        df_raw = fetch_live_data(args.ticker)
    else:
        print("  Using synthetic sample data (500 trading days).")
        df_raw = generate_sample_data()

    print(f"  Rows loaded : {len(df_raw):,}")

    # Feature engineering
    df = add_features(df_raw)
    print(f"  Rows after feature engineering: {len(df):,}")
    print(f"  Features : {len(df.columns) - 1}")

    # Split
    X_train, X_test, y_train, y_test, test_dates = train_test_split_ts(df)
    print(f"  Train / Test split: {len(X_train):,} / {len(X_test):,}")

    # Train
    pipe = build_pipeline()
    pipe.fit(X_train, y_train)

    # Evaluate
    y_pred_train = pipe.predict(X_train)
    y_pred_test  = pipe.predict(X_test)
    evaluate(y_train, y_pred_train, "Train")
    evaluate(y_test,  y_pred_test,  "Test")

    # Feature importance proxy (Ridge coefficients after scaling)
    feature_names = [c for c in df.columns if c != "Target"]
    coef = pipe.named_steps["model"].coef_
    top_idx = np.argsort(np.abs(coef))[::-1][:8]
    print("\n  Top 8 influential features:")
    for i in top_idx:
        print(f"    {feature_names[i]:<18} coef = {coef[i]:+.4f}")

    # Plot
    plot_results(test_dates, y_test, y_pred_test, ticker)

    print("\n  Done!\n")


if __name__ == "__main__":
    main()
