# ML Projects — Codect Technologies Internship

Two end-to-end machine-learning projects built with Python, scikit-learn, NLTK, and Matplotlib.

---

## Project 1 · Stock Price Predictor

**Goal:** Predict a stock's next-day closing price from historical OHLCV data.

### Techniques
| Step | Detail |
|------|--------|
| Data | 500-day synthetic series (or live via `yfinance`) |
| Features | Moving averages (MA5/10/20/50), EMA12/26, MACD, RSI-14, Bollinger Band width, daily return, 10-day volatility, volume z-score, lag-1/2/3/5 close |
| Model | `Ridge` regression wrapped in a `StandardScaler → Ridge` scikit-learn `Pipeline` |
| Split | Chronological 80 / 20 (no data leakage) |
| Metrics | MAE, RMSE, MAPE, R² |

### Results (sample data)
| Set | MAE | RMSE | MAPE | R² |
|-----|-----|------|------|----|
| Train | $1.69 | $2.12 | 1.14% | 0.9633 |
| Test  | $1.88 | $2.31 | 1.20% | **0.8895** |

### Output
Running the script produces `stock_prediction.png` — a two-panel chart showing actual vs predicted prices and the residuals.

### Usage
```bash
# Synthetic data
python stock_price_predictor.py

# Live ticker (requires internet)
python stock_price_predictor.py --ticker AAPL
```

### Requirements
```
numpy pandas scikit-learn matplotlib yfinance
```

---

## Project 2 · Sentiment Analysis on Twitter Data

**Goal:** Classify tweets as **Positive**, **Negative**, or **Neutral** using two complementary approaches.

### Approaches

| Approach | Method | Library |
|----------|--------|---------|
| Rule-based | VADER lexicon (handles slang, emojis, punctuation) | NLTK |
| ML-based | TF-IDF (unigrams + bigrams) + Logistic Regression | scikit-learn |

### Pipeline
1. **Preprocessing** — lowercase, strip URLs / mentions / hashtags / punctuation, remove stopwords, lemmatize
2. **VADER** — score each raw tweet with `SentimentIntensityAnalyzer`; label by compound threshold (±0.05)
3. **ML** — fit `TfidfVectorizer(ngram_range=(1,2)) → LogisticRegression` on cleaned text
4. **Evaluation** — accuracy, precision, recall, F1 (per class), confusion matrix, 5-fold CV

### Results
| Model | Accuracy |
|-------|----------|
| VADER (rule-based) | **83.3%** |
| TF-IDF + Logistic Regression (5-fold CV) | 56.7% ± 13% |

> VADER outperforms the ML model here because the dataset is small (60 tweets). On a larger labelled corpus (e.g. Sentiment140 with 1.6 M tweets) the ML model typically surpasses rule-based approaches.

### Output
`sentiment_analysis.png` — a six-panel dashboard: label distribution, VADER score histogram, cross-validation accuracy, two confusion matrices, and ML-vs-VADER agreement.

### Usage
```bash
python sentiment_analysis.py
```

### Requirements
```
numpy pandas scikit-learn matplotlib nltk textblob
```

---

## Quick Start

```bash
# Install all dependencies
pip install numpy pandas scikit-learn matplotlib yfinance nltk textblob

# Download NLTK data
python -c "import nltk; nltk.download(['vader_lexicon','stopwords','punkt','wordnet'])"

# Run projects
python stock_price_predictor.py
python sentiment_analysis.py
```

---

## Project Structure

```
.
├── stock_price_predictor.py   # Project 1
├── sentiment_analysis.py      # Project 2
├── stock_prediction.png       # Output chart — Project 1
├── sentiment_analysis.png     # Output chart — Project 2
└── README.md
```

---

*Built as part of the Codect Technologies Data Science / ML Internship.*
